-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: university_marketplace
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `sellerId` int NOT NULL,
  `createdAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `category` varchar(255) NOT NULL,
  KEY `userId_idx` (`id`),
  KEY `userId_idx1` (`sellerId`),
  CONSTRAINT `userId` FOREIGN KEY (`sellerId`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (191,'NOTE','NEW',6.00,12,'2024-11-06 09:23:04','2024-11-06 10:54:16','http://localhost:5000/uploads/1730884984647.png',20,'Books'),(192,'SHAVURMA','GARLIC',1.30,12,'2024-11-06 09:23:36','2024-11-06 09:23:36','http://localhost:5000/uploads/1730885016817.png',10,'Other'),(198,'PC','NEW PC',700.00,12,'2024-11-06 09:36:57','2024-11-06 10:54:23','http://localhost:5000/uploads/1730885817672.png',1,'Electronics'),(199,'Iphone','new one ',2.00,12,'2024-11-06 09:37:15','2024-11-06 09:37:15','http://localhost:5000/uploads/1730885835315.png',1200,'Electronics'),(200,'chair 1','ff',60.00,12,'2024-11-06 09:37:38','2024-11-06 09:37:38','http://localhost:5000/uploads/1730885858466.png',5,'Furniture'),(201,'chair 2','gg',80.00,12,'2024-11-06 09:38:02','2024-11-06 09:38:02','http://localhost:5000/uploads/1730885882082.webp',3,'Furniture'),(202,'falafel','new',2.00,12,'2024-11-06 09:38:18','2024-11-06 09:38:18','http://localhost:5000/uploads/1730885898153.webp',6,'Other'),(203,'Kunafa','new',1.40,12,'2024-11-06 09:38:37','2024-11-06 09:38:37','http://localhost:5000/uploads/1730885917674.webp',15,'Other'),(204,'old shvurma','old',0.40,12,'2024-11-06 09:38:59','2024-11-06 09:38:59','http://localhost:5000/uploads/1730885939558.png',465,'Other'),(205,'BOOK 1','1',4.00,12,'2024-11-06 09:39:20','2024-11-06 09:39:20','http://localhost:5000/uploads/1730885960549.png',2,'Books'),(207,'BOOK 3','3',2.00,12,'2024-11-06 09:39:49','2024-11-06 09:39:49','http://localhost:5000/uploads/1730885989604.png',1,'Books'),(208,'BOOK 2','2',8.00,12,'2024-11-06 09:40:38','2024-11-06 09:40:38','http://localhost:5000/uploads/1730886038665.png',4,'Books'),(209,'RED','NEW',15.00,12,'2024-11-06 09:42:09','2024-11-06 09:42:09','http://localhost:5000/uploads/1730886129555.png',14,'Clothing'),(210,'WHITE','NEW',4.00,12,'2024-11-06 09:42:29','2024-11-06 09:42:29','http://localhost:5000/uploads/1730886149490.png',5,'Clothing'),(211,'BLACK','NEW',9.00,12,'2024-11-06 09:43:18','2024-11-06 09:43:18','http://localhost:5000/uploads/1730886198384.webp',14,'Clothing'),(212,'PINK','OLD',9.00,12,'2024-11-06 09:43:32','2024-11-06 09:43:32','http://localhost:5000/uploads/1730886212647.png',11,'Clothing');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-20 11:40:23
