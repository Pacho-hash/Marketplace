-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: university_marketplace
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `phone_number` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (9,'qw','qw@qw4','$2b$10$S17i3ON0ghTKIgRC0VMwg.I3JTwMUk/nifUHyKQlamQiip7DU/AFi','2024-10-21 05:42:39','2024-11-20 22:04:27','user',''),(10,'qw','qw@qw5','$2b$10$n2IpEZ7fBuZDHQi3FOZS9O/6zk11HrzEZCFXyFTlSuc18EqzYNqTG','2024-10-21 05:46:19','2024-10-21 05:46:19','user',''),(12,'qw11','qw@qw11','$2b$10$e3beQNsy.nIbovv5bxB8uOgPms5DW.ClyD2e61s5uKQ0V0fQFB0wC','2024-10-25 18:26:05','2024-11-05 10:51:04','admin','00905338320142'),(13,'qw22','qw@qw22','$2b$10$ZbGmKZhQ4/wb/PI3KPmy2Oje9PH9K21h9aA28vv0T65UGkCW5AkiC','2024-10-30 08:36:30','2024-10-30 08:36:30','user',''),(14,'test5','qw@qw44','$2b$10$ttuyqVlyrYBOb2X9fWS04Op2hiPqBITiHThH9kNPEx1vKiwxvE2zS','2024-10-30 16:46:28','2024-10-30 16:49:14','user',''),(15,'we','we@we','$2b$10$Z0ovIpG9BIl3BlxHpKzMxOJcDkGi/ti6FF.8suvyODpM3pV/phd2.','2024-11-05 10:50:31','2024-11-05 10:50:31','user','00905336532145'),(17,'we','we@we2','$2b$10$Iu4KMgk7UmDdxurTAlvQLenepfgHyJoDfMdlSDaGwjcS6PaYQ/LgO','2024-11-06 11:44:52','2024-11-06 11:45:21','user','0090');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-20 11:40:23
